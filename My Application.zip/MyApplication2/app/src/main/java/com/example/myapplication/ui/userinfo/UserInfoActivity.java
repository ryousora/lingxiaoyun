package com.example.myapplication.ui.userinfo;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.FragmentActivity;

import com.example.myapplication.R;
import com.example.myapplication.action.UploadRequest;
import com.example.myapplication.action.UserRequest;
import com.example.myapplication.model.User;
import com.example.myapplication.utils.Constant;
import com.example.myapplication.utils.ImageUtils;
import com.example.myapplication.utils.ToastUtils;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import butterknife.BindView;
import butterknife.ButterKnife;
import io.reactivex.Flowable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;

/**
 * 账号信息详情页
 * Created by wudeng on 2017/8/31.
 */

public class UserInfoActivity extends FragmentActivity implements View.OnClickListener, View.OnTouchListener {

    private static final String TAG = UserInfoActivity.class.getSimpleName();

    @BindView(R.id.layout_head)
    RelativeLayout mLayoutHead;
    @BindView(R.id.iv_head_picture)
    ImageView mIvHead;
    @BindView(R.id.tv_account_userId)
    TextView mTvUserId;
    @BindView(R.id.et_account_username)
    EditText mEtUsername;
    @BindView(R.id.tv_account_sex)
    TextView mTvSex;
    @BindView(R.id.tv_account_email)
    TextView mTvEmail;
    @BindView(R.id.iv_back_btn)
    ImageView mIvBack;
    @BindView((R.id.iv_menu_btn))
    ImageView mIvMenu;
    // 头像本地路径
    private String mHeadImgPath = "";
    // 获取图像请求码
    private static final int SELECT_PHOTO = 30000;
    private static final int TAKE_PHOTO = 30001;
    // 信息是否有被更新
    private boolean haveAccountChange = false;
    // 是否处于编辑状态
    private boolean isEditor;
    // 输入服务，用于显示键盘
    private InputMethodManager mInputMethodManager;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        setContentView(R.layout.activity_userinfo);
        UserRequest.check(this);
        super.onCreate(savedInstanceState);
        ButterKnife.bind(this);
        UserRequest.getUserInfo(this);
        showData();
        init();
    }

    // 显示数据
    private void showData() {
        if (User.getIconimg_url() != null) {
            /*DownloadRequest.downloadImg(User.getIconimg_url(), User.getUserId());*/
            ImageUtils.setImageByFile(this, mIvHead,
                    User.getIconimg_url(), R.mipmap.bg_img_defalut);
        }
        mTvUserId.setText(User.getUserId());
        mEtUsername.setText(User.getUsername());
        if (User.getGender() == 1) {
            mTvSex.setText("男");
        } else if (User.getGender() == 2) {
            mTvSex.setText("女");
        } else {
            mTvSex.setText("未知");
        }
        if (User.getEmail() != null)
            mTvEmail.setText(User.getEmail());
        else mTvEmail.setText("未知");
    }

    @SuppressLint("ClickableViewAccessibility")
    private void init() {
        mInputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        // 文字
        mLayoutHead.setOnClickListener(this);
        mTvSex.setOnClickListener(this);
        mTvEmail.setOnClickListener(this);

        // 标题栏
        mIvBack.setOnClickListener(this);
        // 输入框
        mEtUsername.setOnTouchListener(this);

        // 结束编辑，相当于初始化为非编辑状态
        finishEdit();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.layout_head:
                setHeadImg();
                break;
            case R.id.tv_account_sex:
                setSex();
                break;
            case R.id.iv_back_btn:
                this.finish();
                break;
            case R.id.iv_menu_btn:
                if (isEditor) {
                    finishEdit();
                } else {
                    startEdit();
                }
                break;
        }
    }

    // EditText 获取焦点并将光标移动到末尾
    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouch(View v, MotionEvent event) {
        if (isEditor) {
            if (v.getId() == R.id.et_account_username) {
                mEtUsername.requestFocus();
                mEtUsername.setSelection(mEtUsername.getText().length());
                mInputMethodManager.showSoftInput(mEtUsername, 0);
            }
            return true;
        }
        return false;
    }

    /**
     * 启动编辑
     */
    private void startEdit() {
        mIvMenu.setImageResource(R.mipmap.done);
        // 可点击
        mLayoutHead.setClickable(true);
        mTvSex.setClickable(true);
        mTvEmail.setClickable(true);
        mEtUsername.setClickable(true);

        isEditor = true;
    }

    /**
     * 结束编辑，判断是否有修改，决定是否同步缓存数据
     */
    private void finishEdit() {
        if (!mEtUsername.getText().toString()
                .equals(User.getUsername())) {
            User.setUsername(mEtUsername.getText().toString());
            haveAccountChange = true;
        }

        if (haveAccountChange) {

            // 将数据更新到服务器
            boolean isSuccess=UserRequest.edit(this);
            if(!isSuccess)
                return;
            // 将数据更新到缓存
            User.saveSP(this);

            haveAccountChange = false;
        }

        mIvMenu.setImageResource(R.mipmap.editor);
        // 不可点击
        mLayoutHead.setClickable(false);
        mTvSex.setClickable(false);
        mTvEmail.setClickable(false);
        // 不可编辑
        mEtUsername.setFocusable(false);
        mEtUsername.setFocusableInTouchMode(false);

        isEditor = false;
    }

    /**
     * 设置性别
     */
    private void setSex(){
        final int[] selected = new int[1];
        if (User.getGender() != 1) {
            if (User.getGender() == 2) {
                selected[0] = 1;//女
            } else {
                selected[0] = 2;//未知
            }
        }  //默认为男

        final String[] items = new String[]{"男", "女", "未知"};
        new AlertDialog.Builder(this)
                .setTitle("性别")
                .setSingleChoiceItems(items, selected[0], new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which != selected[0]) {
                            if (which == 0) {
                                User.setGender((byte)1);
                                mTvSex.setText("男");
                            } else if (which == 1) {
                                User.setGender((byte)2);
                                mTvSex.setText("女");
                            } else {
                                User.setGender((byte)3);
                                mTvSex.setText("未知");
                            }
                            haveAccountChange = true;
                        }
                        dialog.dismiss();
                    }
                }).create().show();
    }

    /**
     * 设置头像，拍照或选择照片
     */
    private void setHeadImg() {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_set_head_img, null);
        final AlertDialog alertDialog = new AlertDialog.Builder(this).setView(view).create();
        TextView take = view.findViewById(R.id.tv_take_photo);
        TextView select = view.findViewById(R.id.tv_select_img);
        take.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
                try {
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    mHeadImgPath = Constant.cachePath + File.separator + "img"
                            + File.separator + User.getUserId() + ".jpg";
                    Uri uri = Uri.fromFile(new File(mHeadImgPath));
                    intent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
                    startActivityForResult(intent, TAKE_PHOTO);
                } catch (Exception e) {
                    ToastUtils.showMessage(UserInfoActivity.this, "启动相机出错！请重试");
                    e.printStackTrace();
                }

            }
        });
        select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
                Intent intent = new Intent(Intent.ACTION_PICK,
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                /*intent.setType("image/*");*/
                startActivityForResult(Intent.createChooser(intent, "选择头像图片"), SELECT_PHOTO);
            }
        });
        alertDialog.show();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == TAKE_PHOTO) {
                dealTakePhotoResult();
            } else if (requestCode == SELECT_PHOTO) {
                mHeadImgPath = ImageUtils.getFilePathFromUri(UserInfoActivity.this, data.getData());
                dealTakePhotoResult();
            }
        }
    }

    /**
     * 处理拍照回传数据
     */
    private void dealTakePhotoResult() {
        Flowable.just(mHeadImgPath)
                .map(new Function<String, Bitmap>() {
                    @Override
                    public Bitmap apply(String path) throws Exception {
                        // 调整旋转角度，压缩
                        int bitmapDegree = ImageUtils.getBitmapDegree(mHeadImgPath);
                        Bitmap bitmap = ImageUtils.getBitmapFromFile(mHeadImgPath, 600, 400);
                        bitmap = ImageUtils.rotateBitmapByDegree(bitmap, bitmapDegree);
                        ImageUtils.saveBitmap2Jpg(bitmap, path);
                        return bitmap;
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<Bitmap>() {
                    @Override
                    public void accept(Bitmap bitmap) throws Exception {
                        // 显示，记录更新，同步至服务器
                        if (bitmap != null) {
                            // 上传至服务器
                            uploadHeadImg(bitmap);
                        }
                    }
                });
    }

    /**
     * 将头像数据上传至网易云服务器存储，获取服务器返回URL
     */
    private void uploadHeadImg(final Bitmap bitmap) {
        String filePath=Constant.imgSavePath+User.getUserId()+".jpg";
        File file=new File(filePath);//将要保存图片的路径
        try {
            BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(file));
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bos);
            bos.flush();
            bos.close();
        }catch (IOException e) {
            e.printStackTrace();
        }

        String url= UploadRequest.uploadImg(this,filePath);
        if(url!=null) {
            Log.e(TAG, "uploadHeadImg onSuccess url = " + url);
            mIvHead.setImageBitmap(bitmap);
            // 保存图片本地路径和服务器路径
            User.setIconimg_url(url);
            haveAccountChange = true;
        } else{
                Log.e(TAG,"uploadHeadImg Failed");
                ToastUtils.showMessage(UserInfoActivity.this,
                        "修改失败，头像上传失败");
            }
    }

}

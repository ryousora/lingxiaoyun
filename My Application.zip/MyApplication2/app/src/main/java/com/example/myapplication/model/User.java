package com.example.myapplication.model;

import android.content.Context;

import com.example.myapplication.utils.MSP;

public class User {
    private static Integer userId;
    private static String username;
    private static String password;
    private  static  String token;
    private static Byte gender;
    private static String email;
    private static String iconimg_url;

    public User() {
        userId=-1;
        token="";
    }

    public User(String username, String password) {
        userId=-1;
        User.username = username;
        User.password = password;
        token="";
    }

    public static void saveSP(Context context){
        MSP.setId(userId,context);
        MSP.setUsername(username,context);
        MSP.setToken(token,context);
    }

    public static void loginOut(Context context){
        userId=-1;
        password=null;
        token=null;
        gender=null;
        email=null;
        iconimg_url=null;
        saveSP(context);
    }

    public static Integer getUserId() {
        return userId;
    }

    public static void setUserId(Integer userId) {
        User.userId = userId;
    }

    public static String getUsername() {
        return username;
    }

    public static void setUsername(String username) {
        User.username = username;
    }

    public static String getPassword() {
        return password;
    }

    public static void setPassword(String password) {
        User.password = password;
    }

    public static Byte getGender() {
        return gender;
    }

    public static void setGender(Byte gender) {
        User.gender = gender;
    }

    public static String getEmail() {
        return email;
    }

    public static void setEmail(String email) {
        User.email = email;
    }

    public static String getIconimg_url() {
        return iconimg_url;
    }

    public static void setIconimg_url(String iconimg_url) {
        User.iconimg_url = iconimg_url;
    }

    public static String getToken() {
        return token;
    }

    public static void setToken(String token) {
        User.token = token;
    }
}

package com.example.myapplication.utils;

import android.os.Environment;

import java.io.File;
import java.util.regex.Pattern;

public class Constant {

    private static String rootStorage= Environment.getRootDirectory().getAbsolutePath();
    private static final String savePath =rootStorage+ File.separator+"sharenote";
    public static final  String imgSavePath=savePath+File.separator+"img";
    public static String cachePath =savePath+File.separator+"cache";
    /*public static final String ipPattern = "`[a-zA-Z0-9][.a-zA-z0-9]+[a-zA-Z0-9]$";*/
    public static final String ipPattern ="([a-zA-Z0-9]+)(\\.[a-zA-Z0-9]+)+";
    public static final String portPattern = "[0-9]{1,5}";
}

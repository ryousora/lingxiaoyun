package com.example.myapplication.action;

import android.content.Context;
import android.util.Log;

import com.example.myapplication.model.Request;
import com.example.myapplication.model.ResponseResult;
import com.example.myapplication.netService.UploadService;
import com.example.myapplication.utils.ToastUtils;

import java.io.File;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UploadRequest {
    public static String uploadImg(final Context context,String filePath) {
        File imgFile=new File(filePath);
        RequestBody requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), imgFile);
        //RequestBody requestFile = RequestBody.create(MediaType.parse("image/jpg"), imgFile);

        // MultipartBody.Part  和后端约定好Key，这里的partName是用file
        MultipartBody.Part body = MultipartBody.Part.createFormData("file", imgFile.getName(), requestFile);
        UploadService service = Request.getRetrofit().create(UploadService.class);

        final ResponseResult[] result = new ResponseResult[1];
        service.uploadImg(body).enqueue(new Callback<ResponseResult>() {
            @Override
            public void onResponse(Call<ResponseResult> call, Response<ResponseResult> response) {
                result[0] =response.body();
                Log.e("", result[0].toString());
                ToastUtils.showMessage(context, "上传成功！");
            }
            @Override
            public void onFailure(Call<ResponseResult> call, Throwable t) {
                ToastUtils.showMessage(context, "上传出错！请重试");
            }
        });
        return (String)result[0].getData().get("url");
    }
}

package com.example.myapplication.netService;

import com.example.myapplication.model.ResponseResult;

import okhttp3.MultipartBody;
import retrofit2.Call;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

public interface UploadService {
    @Multipart
    @POST("image/upload")
    Call<ResponseResult> uploadImg(@Part MultipartBody.Part imgFile);
}

package com.example.myapplication.action;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import com.example.myapplication.model.Request;
import com.example.myapplication.model.ResponseResult;
import com.example.myapplication.model.User;
import com.example.myapplication.model.UserDTO;
import com.example.myapplication.netService.UserService;
import com.example.myapplication.netService.reqbody.LoginReqBody;
import com.example.myapplication.ui.login.LoginActivity;

import java.util.Map;
import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class UserRequest {

    public static void register(final Context context){
        UserService service = Request.getRetrofit().create(UserService.class);
        LoginReqBody user = new LoginReqBody(User.getUsername(),User.getPassword());
        Call<ResponseResult> call = service.register(user);

        Log.e("",  user.getUsername()+"..."+user.getPassword());

        call.enqueue(new Callback<ResponseResult>() {
            @Override
            public void onResponse(Call<ResponseResult> call, Response<ResponseResult> response) {
                ResponseResult result = response.body();
                Log.e("",result.toString());
                    Toast.makeText(context, result.getMessage(), Toast.LENGTH_LONG).show();
                if(result.getStatus()==200) {
                    User.setUsername((String)result.getData().get("username"));
                    User.saveSP(context);
                    ((Activity)context).finish();
                }
            }
            @Override
            public void onFailure(Call<ResponseResult> call, Throwable t) {
                t.printStackTrace();
                Toast.makeText(context, t.toString(), Toast.LENGTH_LONG).show();
            }
        });
    }

    public static void login(final Context context){
        UserService service = Request.getRetrofit().create(UserService.class);
        LoginReqBody user = new LoginReqBody(User.getUsername(),User.getPassword());
        Call<ResponseResult> call = service.login(user);

        Log.e("",  user.getUsername()+"..."+user.getPassword());

        call.enqueue(new Callback<ResponseResult>() {
            @Override
            public void onResponse(Call<ResponseResult> call, Response<ResponseResult> response) {
                ResponseResult result = response.body();
                Map data = result.getData();
                Log.e("",result.toString());
                Toast.makeText(context, result.getMessage(), Toast.LENGTH_LONG).show();
                if(result.getStatus()==200) {
                    User.setUsername((String)data.get("username"));
                    User.setUserId(Integer.valueOf((String) Objects.requireNonNull(data.get("id"))));
                    User.setToken((String)data.get("token"));
                    User.saveSP(context);
                    ((Activity)context).finish();
                }
            }
            @Override
            public void onFailure(Call<ResponseResult> call, Throwable t) {
                t.printStackTrace();
                Toast.makeText(context, t.toString(), Toast.LENGTH_LONG).show();
            }
        });
    }

    public static void getUserInfo(final Context context){
        UserService service = Request.getRetrofit().create(UserService.class);
        LoginReqBody user = new LoginReqBody(User.getUsername(),User.getPassword());
        Call<ResponseResult> call = service.getUserInfo(user);

        Log.e("",  user.getUsername()+"..."+user.getPassword());

        call.enqueue(new Callback<ResponseResult>() {
            @Override
            public void onResponse(Call<ResponseResult> call, Response<ResponseResult> response) {
                ResponseResult result = response.body();
                Map data = result.getData();
                UserDTO user = (UserDTO)data.get("user");
                Log.e("",result.toString());
                Toast.makeText(context, result.getMessage(), Toast.LENGTH_LONG).show();
                if(result.getStatus()==201) {
                    assert user != null;
                    User.setUsername(user.getUsername());
                    User.setUserId(user.getUserId());
                    User.setGender((user.getGender()));
                    User.setEmail(user.getEmail());
                    User.setIconimg_url(user.getIconimgUrl());
                    User.setToken((String)data.get("token"));
                    User.saveSP(context);
                }else {
                    Toast.makeText(context, "系统出错！", Toast.LENGTH_LONG).show();
                    Intent intent=new Intent(context, LoginActivity.class);
                    context.startActivity(intent);
                    ((Activity)context).finish();
                }
            }
            @Override
            public void onFailure(Call<ResponseResult> call, Throwable t) {
                t.printStackTrace();
                Toast.makeText(context, t.toString(), Toast.LENGTH_LONG).show();
            }
        });
    }

    public static void check(final Context context){
        UserService service = Request.getRetrofit().create(UserService.class);
        LoginReqBody user = new LoginReqBody(User.getUsername(),User.getPassword());
        Call<ResponseResult> call = service.check(User.getToken(),user);

        Log.e("",  user.getUsername()+"..."+user.getPassword());

        call.enqueue(new Callback<ResponseResult>() {
            @Override
            public void onResponse(Call<ResponseResult> call, Response<ResponseResult> response) {
                ResponseResult result = response.body();
                Map data = result.getData();
                Log.e("",result.toString());
                Toast.makeText(context, result.getMessage(), Toast.LENGTH_LONG).show();
                if(result.getStatus()==200) {
                    User.setUsername((String) data.get("username"));
                    User.setUserId((int) data.get("id"));
                    User.saveSP(context);
                }else{
                    /*Toast.makeText(context, "验证出错，请重新登录", Toast.LENGTH_LONG).show();*/
                    Intent intent=new Intent(context, LoginActivity.class);
                    context.startActivity(intent);
                    ((Activity) context).finish();
                }
            }
            @Override
            public void onFailure(Call<ResponseResult> call, Throwable t) {
                t.printStackTrace();
                Log.e("",t.toString());
                Toast.makeText(context, t.toString(), Toast.LENGTH_LONG).show();
            }
        });
    }

    public static boolean edit(final Context context){
        UserService service = Request.getRetrofit().create(UserService.class);
        final LoginReqBody user = new LoginReqBody(User.getUsername(),User.getPassword());
        Call<ResponseResult> call = service.edit(User.getUsername(),user);

        Log.e("",  user.getUsername()+"..."+user.getPassword());

        final boolean[] isSuccess = {false};
        call.enqueue(new Callback<ResponseResult>() {
            @Override
            public void onResponse(Call<ResponseResult> call, Response<ResponseResult> response) {
                ResponseResult result = response.body();
                Map data = result.getData();
                Log.e("",result.toString());
                Toast.makeText(context, result.getMessage(), Toast.LENGTH_LONG).show();
                if(result.getStatus()==201) {
                    isSuccess[0] =true;
                    Toast.makeText(context, "修改成功！", Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(context, "修改失败，请稍后重试", Toast.LENGTH_LONG).show();
                }
            }
            @Override
            public void onFailure(Call<ResponseResult> call, Throwable t) {
                t.printStackTrace();
                Toast.makeText(context, t.toString(), Toast.LENGTH_LONG).show();
            }
        });
        return isSuccess[0];
    }
}

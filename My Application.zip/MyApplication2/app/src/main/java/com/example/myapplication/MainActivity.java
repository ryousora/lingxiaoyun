package com.example.myapplication;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.myapplication.model.Url;
import com.example.myapplication.model.User;
import com.example.myapplication.ui.login.LoginActivity;
import com.example.myapplication.ui.userinfo.UserInfoActivity;
import com.example.myapplication.utils.MSP;
import com.google.android.material.navigation.NavigationView;

import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_gallery, R.id.nav_slideshow,
                R.id.nav_tools, R.id.nav_share)
                .setDrawerLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);
        Url.initUrl(MainActivity.this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);

        ImageView imageView=findViewById(R.id.imageView);
        imageView.setOnClickListener(new ImageView.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent;
                if(User.getToken()!=null)
                    intent = new Intent(MainActivity.this, UserInfoActivity.class);
                else intent=new Intent((MainActivity.this), LoginActivity.class);
                startActivity(intent);
            }
            }
        );

        return true;
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_settings) {
            Url.initUrl(MainActivity.this);
            LayoutInflater factory = LayoutInflater.from(MainActivity.this);
            @SuppressLint("InflateParams") final View view = factory.inflate(R.layout.ip_setting, null);
            final EditText ip_edit = view.findViewById(R.id.ip);
            final EditText port_edit = view.findViewById(R.id.port);
            ip_edit.setHint("ip");
            ip_edit.setText(Url.getIp());
            port_edit.setHint("port");
            port_edit.setText(Url.getPort());
            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("请输入服务器地址")
                    .setView(view)
                    .setPositiveButton("确定",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    String ip=ip_edit.getText().toString();
                                    String port=port_edit.getText().toString();
                                    Log.e("",ip+"::::::::::"+port);
                                    new Url(ip,port);
                                    Url.saveUrl(MainActivity.this);
                                }
                            }).setNegativeButton("取消", null).create().show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

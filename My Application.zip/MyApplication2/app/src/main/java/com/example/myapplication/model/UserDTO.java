package com.example.myapplication.model;

import java.util.Date;

public class UserDTO {

    private Integer userId;

    private String username;

    private Byte gender;

    private String email;

    private String iconimgUrl;

    private Date lastLogin;


    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username == null ? null : username.trim();
    }

    public Byte getGender() {
        return gender;
    }

    public void setGender(Byte gender) {
        this.gender = gender;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email == null ? null : email.trim();
    }

    public String getIconimgUrl() {
        return iconimgUrl;
    }

    public void setIconimgUrl(String iconimgUrl) {
        this.iconimgUrl = iconimgUrl == null ? null : iconimgUrl.trim();
    }

    public Date getLastLogin() {
        return lastLogin;
    }

    public void setLastLogin(Date lastLogin) {
        this.lastLogin = lastLogin;
    }
}